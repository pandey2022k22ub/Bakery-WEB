import React from 'react';

function Confirmation() {
  return (
    <h1>Checkout succeeded</h1>
  );
}

export default Confirmation;
